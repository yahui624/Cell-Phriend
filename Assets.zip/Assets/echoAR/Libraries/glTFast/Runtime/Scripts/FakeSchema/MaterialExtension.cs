﻿namespace GLTFast.FakeSchema {

    [System.Serializable]
    public class MaterialExtension {
        public string KHR_materials_pbrSpecularGlossiness;
        public string KHR_materials_unlit;
    }
}
