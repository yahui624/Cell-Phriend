﻿namespace GLTFast.Schema {

    [System.Serializable]
    public class RootChild {
        public string name;        
    }
}
