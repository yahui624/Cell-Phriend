﻿namespace GLTFast.Schema {

    [System.Serializable]
    public class Scene : RootChild {
        public uint[] nodes;
    }
}
