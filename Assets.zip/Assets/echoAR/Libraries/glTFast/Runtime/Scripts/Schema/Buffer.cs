﻿namespace GLTFast.Schema {

    [System.Serializable]
    public class Buffer {
        public uint byteLength;
        public string uri;
    }
}