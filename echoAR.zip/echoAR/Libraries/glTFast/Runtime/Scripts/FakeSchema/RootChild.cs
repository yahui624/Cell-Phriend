﻿
namespace GLTFast.FakeSchema {

    [System.Serializable]
    public class RootChild {
        public string name;        
    }
}
