namespace GLTFast.Schema {
    [System.Serializable]
    public class MaterialUnlit {
    }
}
