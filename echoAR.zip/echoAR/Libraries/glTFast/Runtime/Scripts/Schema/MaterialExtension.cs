namespace GLTFast.Schema {

    [System.Serializable]
    public class MaterialExtension {
        public PbrSpecularGlossiness KHR_materials_pbrSpecularGlossiness;
        public MaterialUnlit KHR_materials_unlit;
    }
}
