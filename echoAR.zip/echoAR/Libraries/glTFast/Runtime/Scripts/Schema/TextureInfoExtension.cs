﻿
namespace GLTFast.Schema {
    [System.Serializable]
    public class TextureInfoExtension {
        public TextureTransform KHR_texture_transform;
    }
}
